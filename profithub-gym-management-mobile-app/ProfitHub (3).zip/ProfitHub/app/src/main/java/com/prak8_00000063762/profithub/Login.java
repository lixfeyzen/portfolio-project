package com.prak8_00000063762.profithub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.imageview.ShapeableImageView;

import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ImageView;

import com.google.android.material.imageview.ShapeableImageView;
import android.widget.TextView;

public class Login extends AppCompatActivity {

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_login);



                TextView textView = findViewById(R.id.signup); // Replace with your TextView ID
                textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        // Start SecondActivity
                        Intent intent = new Intent(Login.this, SignUp.class);
                        startActivity(intent);

                    }

                });
            }
        }



