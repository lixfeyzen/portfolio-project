package com.prak8_00000063762.profithub;

import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import android.os.Bundle;
import android.view.View;
import android.widget.SearchView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.MapView;
import com.prak8_00000063762.profithub.databinding.ActivityMapGymBinding;

public class mapGym extends FragmentActivity implements OnMapReadyCallback {


    private SearchView searchView;
    private MapView mapView;
    private RecyclerView popularGymRecyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map_gym);

        // Initialize views
        searchView = findViewById(R.id.searchView);
        mapView = findViewById(R.id.mapView);
        popularGymRecyclerView = findViewById(R.id.popularGymRecyclerView);

        // Set up the map
        mapView.onCreate(savedInstanceState);
        // You need to handle the map lifecycle, refer to Google Maps documentation

        // Set up the RecyclerView
        LinearLayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false);
        popularGymRecyclerView.setLayoutManager(layoutManager);

        // Dummy data for the RecyclerView (replace this with your actual data)
        String[] popularGyms = {"Gym 1", "Gym 2", "Gym 3", "Gym 4", "Gym 5"};

        // Set up the RecyclerView adapter
        GymAdapter gymAdapter = new GymAdapter(popularGyms);
        popularGymRecyclerView.setAdapter(gymAdapter);

        // Set up a click listener for the searchView
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                // Handle the search query submission
                Toast.makeText(mapGym.this, "Search: " + query, Toast.LENGTH_SHORT).show();
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Handle the search query text change
                return false;
            }
        });
    }

    // You may need to override other lifecycle methods for the MapView
    // For example:
    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }
}