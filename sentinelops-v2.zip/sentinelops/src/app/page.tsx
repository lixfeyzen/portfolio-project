'use client';

import { useState, useEffect } from 'react';
import { ViewMode } from '@/lib/types';
import { useSimulator } from '@/hooks/useSimulator';

import { Sidebar } from '@/components/layout/Sidebar';
import { Header } from '@/components/layout/Header';

import { KPICards } from '@/components/dashboard/KPICards';
import { RiskScoreCard } from '@/components/dashboard/RiskScoreCard';
import { AlertsPanel } from '@/components/dashboard/AlertsPanel';
import { ScenarioSimulator } from '@/components/dashboard/ScenarioSimulator';
import { RestockRecommendations } from '@/components/dashboard/RestockRecommendations';

import { InventoryTable } from '@/components/inventory/InventoryTable';

import { StockTrendsChart } from '@/components/analytics/StockTrendsChart';
import { CategoryDistribution } from '@/components/analytics/CategoryDistribution';
import { MovementVelocity } from '@/components/analytics/MovementVelocity';

import { SkeletonKPIGrid, SkeletonDashboardGrid, SkeletonChart, SkeletonTable } from '@/components/ui/Skeleton';

export default function Home() {
  const [activeView, setActiveView] = useState<ViewMode>('dashboard');
  const [loading, setLoading] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const {
    params, setDemandMultiplier, setLeadTimeMultiplier, resetParams,
    products, riskAssessments, alerts, kpis, movementData, categoryData,
  } = useSimulator();

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(timer);
  }, []);

  const handleViewChange = (view: ViewMode) => {
    if (view === activeView) return;
    setLoading(true);
    setActiveView(view);
    setTimeout(() => setLoading(false), 400);
  };

  const criticalAlerts = alerts.filter((a) => a.severity === 'critical').length;

  return (
    <div className="min-h-screen bg-surface-1">
      <Sidebar
        activeView={activeView}
        onViewChange={handleViewChange}
        alertCount={criticalAlerts}
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />

      {/* Main content: offset for desktop sidebar, no offset on mobile */}
      <div className="lg:ml-[220px]">
        <Header
          activeView={activeView}
          params={params}
          onMenuToggle={() => setMobileMenuOpen(true)}
        />

        {/* pb-20 on mobile for bottom nav clearance */}
        <main className="p-4 sm:p-6 max-w-[1400px] pb-24 sm:pb-6">

          {/* ========== DASHBOARD ========== */}
          {activeView === 'dashboard' && (
            <div className="space-y-4 sm:space-y-6">
              {loading ? (
                <>
                  <SkeletonKPIGrid />
                  <SkeletonDashboardGrid />
                </>
              ) : (
                <>
                  <KPICards data={kpis} />
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
                    <RiskScoreCard assessments={riskAssessments} />
                    <AlertsPanel alerts={alerts} />
                    <div className="space-y-4 sm:space-y-6">
                      <ScenarioSimulator
                        params={params}
                        onDemandChange={setDemandMultiplier}
                        onLeadTimeChange={setLeadTimeMultiplier}
                        onReset={resetParams}
                        kpis={kpis}
                        alertCount={alerts.length}
                        assessments={riskAssessments}
                      />
                      <RestockRecommendations assessments={riskAssessments} />
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {/* ========== INVENTORY ========== */}
          {activeView === 'inventory' && (
            <div className="space-y-4 sm:space-y-6">
              {loading ? <SkeletonTable /> : (
                <InventoryTable products={products} params={params} />
              )}
            </div>
          )}

          {/* ========== ANALYTICS ========== */}
          {activeView === 'analytics' && (
            <div className="space-y-4 sm:space-y-6">
              {loading ? (
                <>
                  <SkeletonChart />
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    <SkeletonChart />
                    <SkeletonChart />
                  </div>
                </>
              ) : (
                <>
                  <StockTrendsChart products={products} params={params} />
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    <CategoryDistribution data={categoryData} />
                    <MovementVelocity data={movementData} />
                  </div>
                </>
              )}
            </div>
          )}

          {/* ========== SIMULATOR ========== */}
          {activeView === 'simulator' && (
            <div className="space-y-4 sm:space-y-6">
              {loading ? (
                <>
                  <SkeletonChart />
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    <SkeletonChart />
                    <SkeletonChart />
                  </div>
                </>
              ) : (
                <>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
                    <ScenarioSimulator
                      params={params}
                      onDemandChange={setDemandMultiplier}
                      onLeadTimeChange={setLeadTimeMultiplier}
                      onReset={resetParams}
                      kpis={kpis}
                      alertCount={alerts.length}
                      assessments={riskAssessments}
                    />
                    <div className="lg:col-span-2">
                      <KPICards data={kpis} />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    <RiskScoreCard assessments={riskAssessments} />
                    <AlertsPanel alerts={alerts} />
                  </div>

                  <StockTrendsChart products={products} params={params} />

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                    <MovementVelocity data={movementData} />
                    <RestockRecommendations assessments={riskAssessments} />
                  </div>
                </>
              )}
            </div>
          )}
        </main>
      </div>
    </div>
  );
}
