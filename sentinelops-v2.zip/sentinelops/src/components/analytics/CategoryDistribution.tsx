'use client';

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import { CategoryDistItem } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { getCategoryColor, formatCompact } from '@/lib/utils';

interface CategoryDistProps { data: CategoryDistItem[]; }

export function CategoryDistribution({ data }: CategoryDistProps) {
  const total = data.reduce((s, d) => s + d.value, 0);

  const CustomTooltip = ({ active, payload }: any) => {
    if (!active || !payload?.length) return null;
    const d = payload[0].payload;
    return (
      <div className="bg-surface-0 border border-border rounded-lg px-3 py-2 shadow-lg text-xs">
        <p className="font-medium text-text-primary">{d.category}</p>
        <p className="text-text-secondary mt-0.5">{d.count} products · {formatCompact(d.value)}</p>
      </div>
    );
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle>Category Distribution</CardTitle>
      </CardHeader>

      <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6">
        <div className="w-36 h-36 sm:w-40 sm:h-40 flex-shrink-0">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie data={data} cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={2} dataKey="value" stroke="none">
                {data.map((_, i) => <Cell key={i} fill={getCategoryColor(i)} />)}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>
        </div>

        <div className="flex-1 space-y-2 w-full">
          {data.map((item, i) => {
            const pct = total > 0 ? ((item.value / total) * 100).toFixed(1) : '0';
            return (
              <div key={item.category} className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-sm flex-shrink-0" style={{ background: getCategoryColor(i) }} />
                <span className="text-xs text-text-secondary flex-1 truncate">{item.category}</span>
                <span className="text-xs font-mono font-medium text-text-primary">{pct}%</span>
              </div>
            );
          })}
        </div>
      </div>
    </Card>
  );
}
