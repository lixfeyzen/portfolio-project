'use client';

import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { MovementData } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';

interface MovementProps { data: MovementData[]; }

export function MovementVelocity({ data }: MovementProps) {
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-surface-0 border border-border rounded-lg px-3 py-2 shadow-lg text-xs">
        <p className="font-medium text-text-primary mb-1">{label}</p>
        <p className="text-text-secondary">
          Velocity: <span className="font-medium text-text-primary">{payload[0]?.value} units/day</span>
        </p>
      </div>
    );
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle>Movement Velocity — Top 10</CardTitle>
      </CardHeader>

      <div className="h-56 sm:h-64">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} layout="vertical" margin={{ top: 0, right: 10, left: 0, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" horizontal={false} />
            <XAxis type="number" tick={{ fontSize: 10 }} />
            <YAxis dataKey="name" type="category" width={100} tick={{ fontSize: 10 }} />
            <Tooltip content={<CustomTooltip />} />
            <Bar dataKey="velocity" fill="#3b82f6" radius={[0, 4, 4, 0]} barSize={14} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </Card>
  );
}
