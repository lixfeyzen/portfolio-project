'use client';

import { useMemo, useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import { Product, SimulatorParams } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { generateStockTrends } from '@/data/mock-data';

interface StockTrendsProps {
  products: Product[];
  params: SimulatorParams;
}

export function StockTrendsChart({ products, params }: StockTrendsProps) {
  const [selectedId, setSelectedId] = useState(products[0]?.id || '');
  const product = products.find((p) => p.id === selectedId) || products[0];

  const data = useMemo(() => {
    if (!product) return [];
    return generateStockTrends(product).map((t) => ({
      ...t,
      projected: t.projected ? Math.max(0, Math.round(t.projected / params.demandMultiplier)) : 0,
      reorderPoint: product.reorderPoint,
    }));
  }, [product, params.demandMultiplier]);

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (!active || !payload?.length) return null;
    return (
      <div className="bg-surface-0 border border-border rounded-lg px-3 py-2 shadow-lg text-xs">
        <p className="text-text-tertiary mb-1">{label}</p>
        {payload.map((p: any, i: number) => (
          p.value > 0 && (
            <div key={i} className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full" style={{ background: p.color }} />
              <span className="text-text-secondary capitalize">{p.dataKey}:</span>
              <span className="font-medium text-text-primary">{p.value}</span>
            </div>
          )
        ))}
      </div>
    );
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex-col sm:flex-row gap-2">
        <CardTitle>Stock Trend & Forecast</CardTitle>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value)}
          className="select-styled text-sm sm:text-xs bg-surface-1 border border-border rounded-lg px-2.5 py-2 sm:py-1.5
            focus:outline-none focus:ring-2 focus:ring-accent/30 text-text-secondary appearance-none cursor-pointer w-full sm:max-w-[200px]"
        >
          {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </CardHeader>

      <div className="h-52 sm:h-64">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 10, left: -15, bottom: 0 }}>
            <defs>
              <linearGradient id="stockGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.15} />
                <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
              </linearGradient>
              <linearGradient id="projGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f59e0b" stopOpacity={0.15} />
                <stop offset="100%" stopColor="#f59e0b" stopOpacity={0} />
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} />
            <XAxis dataKey="date" tickFormatter={(v) => { const d = new Date(v); return `${d.getMonth() + 1}/${d.getDate()}`; }} tick={{ fontSize: 10 }} interval="preserveStartEnd" />
            <YAxis tick={{ fontSize: 10 }} width={35} />
            <Tooltip content={<CustomTooltip />} />
            <Area type="monotone" dataKey="stock" stroke="#3b82f6" strokeWidth={2} fill="url(#stockGrad)" dot={false} />
            <Area type="monotone" dataKey="projected" stroke="#f59e0b" strokeWidth={2} strokeDasharray="6 3" fill="url(#projGrad)" dot={false} />
            <Area type="monotone" dataKey="reorderPoint" stroke="#ef4444" strokeWidth={1} strokeDasharray="4 4" fill="none" dot={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 mt-3 pt-3 border-t border-border">
        <div className="flex items-center gap-1.5 text-[10px] text-text-tertiary">
          <span className="w-3 h-0.5 bg-blue-500 rounded" />Actual Stock
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-text-tertiary">
          <span className="w-3 h-0.5 bg-amber-500 rounded" />Projected
        </div>
        <div className="flex items-center gap-1.5 text-[10px] text-text-tertiary">
          <span className="w-3 h-0.5 bg-red-500 rounded" />Reorder Point
        </div>
      </div>
    </Card>
  );
}
