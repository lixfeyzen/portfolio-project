'use client';

import { Alert } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { cn } from '@/lib/utils';

interface AlertsPanelProps {
  alerts: Alert[];
}

const alertIcons = {
  stockout: (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
      <line x1="12" y1="9" x2="12" y2="13" />
      <line x1="12" y1="17" x2="12.01" y2="17" />
    </svg>
  ),
  overstock: (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
      <path d="m3.3 7 8.7 5 8.7-5M12 22V12" />
    </svg>
  ),
  'high-risk': (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
      <path d="M12 8v4M12 16h.01" />
    </svg>
  ),
  reorder: (
    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16" />
      <path d="M8 16H3v5" />
    </svg>
  ),
};

const severityStyles = {
  critical: {
    bg: 'bg-red-500/5 border-red-500/20',
    icon: 'text-red-500',
    dot: 'bg-red-500',
  },
  warning: {
    bg: 'bg-amber-500/5 border-amber-500/20',
    icon: 'text-amber-500',
    dot: 'bg-amber-500',
  },
  info: {
    bg: 'bg-blue-500/5 border-blue-500/20',
    icon: 'text-blue-500',
    dot: 'bg-blue-500',
  },
};

export function AlertsPanel({ alerts }: AlertsPanelProps) {
  const visibleAlerts = alerts.slice(0, 8);
  const criticalCount = alerts.filter((a) => a.severity === 'critical').length;

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle>Smart Alerts</CardTitle>
        <div className="flex gap-1.5">
          {criticalCount > 0 && (
            <Badge variant="danger" dot>
              {criticalCount} critical
            </Badge>
          )}
          <Badge variant="muted">{alerts.length} total</Badge>
        </div>
      </CardHeader>

      <div className="space-y-2 max-h-[400px] overflow-y-auto pr-1">
        {visibleAlerts.length === 0 && (
          <div className="text-center py-8">
            <div className="w-10 h-10 mx-auto mb-2 rounded-full bg-emerald-500/10 flex items-center justify-center">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="text-emerald-500">
                <path d="M20 6L9 17l-5-5" />
              </svg>
            </div>
            <p className="text-xs text-text-tertiary">All clear — no alerts</p>
          </div>
        )}

        {visibleAlerts.map((alert) => {
          const style = severityStyles[alert.severity];
          return (
            <div
              key={alert.id}
              className={cn(
                'flex items-start gap-2.5 p-3 rounded-lg border transition-colors',
                style.bg
              )}
            >
              <span className={cn('mt-0.5 flex-shrink-0', style.icon)}>
                {alertIcons[alert.type]}
              </span>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-text-primary">
                  {alert.productName}
                </p>
                <p className="text-[11px] text-text-secondary mt-0.5 leading-relaxed">
                  {alert.message}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
