'use client';

import { KPIData } from '@/lib/types';
import { formatCompact } from '@/lib/utils';
import { Card } from '@/components/ui/Card';

interface KPICardsProps {
  data: KPIData;
}

interface KPIItem {
  label: string;
  value: string;
  sub: string;
  color: string;
  icon: JSX.Element;
}

export function KPICards({ data }: KPICardsProps) {
  const items: KPIItem[] = [
    {
      label: 'Total Inventory Value',
      value: formatCompact(data.totalInventoryValue),
      sub: `${data.totalProducts} products tracked`,
      color: 'text-blue-600 dark:text-blue-400',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M12 2v20M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6" />
        </svg>
      ),
    },
    {
      label: 'Critical Risk Items',
      value: String(data.criticalRiskItems),
      sub: `Avg risk score: ${data.avgRiskScore}`,
      color: data.criticalRiskItems > 3 ? 'text-red-600 dark:text-red-400' : data.criticalRiskItems > 0 ? 'text-amber-600 dark:text-amber-400' : 'text-emerald-600 dark:text-emerald-400',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
          <line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" />
        </svg>
      ),
    },
    {
      label: 'Overstock Items',
      value: String(data.overstockItems),
      sub: 'Above max capacity',
      color: data.overstockItems > 2 ? 'text-amber-600 dark:text-amber-400' : 'text-text-secondary',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
          <path d="m3.3 7 8.7 5 8.7-5M12 22V12" />
        </svg>
      ),
    },
    {
      label: 'Fast Moving Products',
      value: String(data.fastMovingProducts),
      sub: '≥8 units/day velocity',
      color: 'text-emerald-600 dark:text-emerald-400',
      icon: (
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z" />
        </svg>
      ),
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4">
      {items.map((item, i) => (
        <Card key={i} hover className="animate-fade-in" style={{ animationDelay: `${i * 60}ms` }}>
          <div className="flex items-start justify-between">
            <div className="min-w-0">
              <p className="text-[11px] font-medium text-text-tertiary uppercase tracking-wider mb-1">{item.label}</p>
              <p className={`text-xl sm:text-2xl font-bold tracking-tight ${item.color}`}>{item.value}</p>
              <p className="text-[11px] text-text-tertiary mt-1">{item.sub}</p>
            </div>
            <div className="w-9 h-9 rounded-lg bg-surface-2 flex items-center justify-center text-text-tertiary flex-shrink-0">
              {item.icon}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
