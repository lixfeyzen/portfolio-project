'use client';

import { Product, RiskAssessment } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { formatCurrency, formatNumber } from '@/lib/utils';

interface RestockProps {
  assessments: { product: Product; risk: RiskAssessment }[];
}

export function RestockRecommendations({ assessments }: RestockProps) {
  const needsReorder = assessments
    .filter((a) => a.risk.suggestedReorder > 0 && !a.risk.isOverstocked)
    .sort((a, b) => b.risk.score - a.risk.score)
    .slice(0, 5);

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle>Restock Recommendations</CardTitle>
        <Badge variant="info">{needsReorder.length} items</Badge>
      </CardHeader>

      <div className="space-y-2.5">
        {needsReorder.length === 0 && (
          <div className="text-center py-6">
            <p className="text-xs text-text-tertiary">No restock needed at this time</p>
          </div>
        )}

        {needsReorder.map(({ product, risk }) => {
          const cost = risk.suggestedReorder * product.unitCost;
          return (
            <div
              key={product.id}
              className="p-3 rounded-lg bg-surface-1 hover:bg-surface-2 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="min-w-0 flex-1">
                  <p className="text-xs font-medium text-text-primary truncate">
                    {product.name}
                  </p>
                  <p className="text-[10px] text-text-tertiary mt-0.5">
                    {product.supplier} · {product.leadTimeDays}d lead time
                  </p>
                </div>
                <Badge
                  variant={risk.level === 'critical' ? 'danger' : 'warning'}
                  className="ml-2 text-[10px]"
                >
                  Risk {risk.score}
                </Badge>
              </div>
              <div className="flex items-center justify-between bg-surface-0 rounded-md p-2 border border-border-subtle">
                <div>
                  <p className="text-[10px] text-text-tertiary">Order Quantity</p>
                  <p className="text-sm font-bold text-accent">
                    {formatNumber(risk.suggestedReorder)} units
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-[10px] text-text-tertiary">Est. Cost</p>
                  <p className="text-sm font-semibold text-text-primary">
                    {formatCurrency(cost)}
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
