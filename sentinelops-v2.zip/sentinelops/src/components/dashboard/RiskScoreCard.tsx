'use client';

import { Product, RiskAssessment } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { cn, getRiskBg } from '@/lib/utils';

interface RiskScoreCardProps {
  assessments: { product: Product; risk: RiskAssessment }[];
}

export function RiskScoreCard({ assessments }: RiskScoreCardProps) {
  const sorted = [...assessments].sort((a, b) => b.risk.score - a.risk.score);
  const topRisks = sorted.slice(0, 6);

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <CardTitle>Risk Scoring Engine</CardTitle>
        <Badge variant="muted">{assessments.length} products</Badge>
      </CardHeader>

      <div className="space-y-2.5">
        {topRisks.map(({ product, risk }) => (
          <div
            key={product.id}
            className="flex items-center gap-3 p-3 rounded-lg bg-surface-1 hover:bg-surface-2 transition-colors group"
          >
            {/* Risk gauge */}
            <div className="relative w-10 h-10 flex-shrink-0">
              <svg viewBox="0 0 36 36" className="w-10 h-10 -rotate-90">
                <circle
                  cx="18"
                  cy="18"
                  r="15"
                  fill="none"
                  stroke="var(--surface-3)"
                  strokeWidth="3"
                />
                <circle
                  cx="18"
                  cy="18"
                  r="15"
                  fill="none"
                  stroke={
                    risk.level === 'critical'
                      ? 'var(--risk-critical)'
                      : risk.level === 'high'
                      ? 'var(--risk-high)'
                      : risk.level === 'medium'
                      ? 'var(--risk-medium)'
                      : 'var(--risk-low)'
                  }
                  strokeWidth="3"
                  strokeDasharray={`${(risk.score / 100) * 94.25} 94.25`}
                  strokeLinecap="round"
                  className="transition-all duration-500"
                />
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-text-primary">
                {risk.score}
              </span>
            </div>

            {/* Info */}
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-text-primary truncate">
                {product.name}
              </p>
              <p className="text-[10px] text-text-tertiary mt-0.5">
                {product.sku} · {product.currentStock} units
              </p>
            </div>

            {/* Risk level badge */}
            <Badge
              variant={
                risk.level === 'critical'
                  ? 'danger'
                  : risk.level === 'high'
                  ? 'warning'
                  : risk.level === 'medium'
                  ? 'info'
                  : 'success'
              }
              className="text-[10px] uppercase"
              dot
            >
              {risk.level}
            </Badge>
          </div>
        ))}
      </div>
    </Card>
  );
}
