'use client';

import { SimulatorParams, Product, RiskAssessment } from '@/lib/types';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { cn } from '@/lib/utils';

interface SimulatorProps {
  params: SimulatorParams;
  onDemandChange: (v: number) => void;
  onLeadTimeChange: (v: number) => void;
  onReset: () => void;
  kpis: { criticalRiskItems: number };
  alertCount: number;
  assessments: { product: Product; risk: RiskAssessment }[];
}

export function ScenarioSimulator({ params, onDemandChange, onLeadTimeChange, onReset, kpis, alertCount, assessments }: SimulatorProps) {
  const isActive = params.demandMultiplier !== 1 || params.leadTimeMultiplier !== 1;
  const criticalCount = assessments.filter((a) => a.risk.level === 'critical').length;
  const highCount = assessments.filter((a) => a.risk.level === 'high').length;

  return (
    <Card className="animate-fade-in">
      <CardHeader>
        <div className="flex items-center gap-2">
          <CardTitle>Scenario Simulator</CardTitle>
          {isActive && <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />}
        </div>
        {isActive && (
          <button
            onClick={onReset}
            className="text-[11px] font-medium text-text-tertiary hover:text-text-primary transition-colors px-2 py-1 rounded-md hover:bg-surface-2"
          >
            Reset
          </button>
        )}
      </CardHeader>

      <div className="space-y-5">
        {/* Demand Slider */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <label className="text-xs font-medium text-text-secondary">Demand Change</label>
            <span className={cn('text-xs font-bold font-mono', params.demandMultiplier > 1.5 ? 'text-red-500' : params.demandMultiplier > 1 ? 'text-amber-500' : 'text-text-primary')}>
              {params.demandMultiplier > 1 ? '+' : ''}{Math.round((params.demandMultiplier - 1) * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0.5}
            max={3}
            step={0.1}
            value={params.demandMultiplier}
            onChange={(e) => onDemandChange(parseFloat(e.target.value))}
            className="w-full h-2 rounded-full appearance-none cursor-pointer bg-surface-3 touch-pan-x
              [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5
              [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-accent [&::-webkit-slider-thumb]:shadow-md
              [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-surface-0
              [&::-webkit-slider-thumb]:transition-transform [&::-webkit-slider-thumb]:hover:scale-110
              [&::-webkit-slider-thumb]:active:scale-95"
          />
          <div className="flex justify-between text-[10px] text-text-tertiary mt-1.5">
            <span>-50%</span><span>Normal</span><span>+200%</span>
          </div>
        </div>

        {/* Lead Time Slider */}
        <div>
          <div className="flex items-center justify-between mb-2.5">
            <label className="text-xs font-medium text-text-secondary">Lead Time Change</label>
            <span className={cn('text-xs font-bold font-mono', params.leadTimeMultiplier > 1.5 ? 'text-red-500' : params.leadTimeMultiplier > 1 ? 'text-amber-500' : 'text-text-primary')}>
              {params.leadTimeMultiplier > 1 ? '+' : ''}{Math.round((params.leadTimeMultiplier - 1) * 100)}%
            </span>
          </div>
          <input
            type="range"
            min={0.5}
            max={3}
            step={0.1}
            value={params.leadTimeMultiplier}
            onChange={(e) => onLeadTimeChange(parseFloat(e.target.value))}
            className="w-full h-2 rounded-full appearance-none cursor-pointer bg-surface-3 touch-pan-x
              [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-5 [&::-webkit-slider-thumb]:h-5
              [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-accent [&::-webkit-slider-thumb]:shadow-md
              [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-surface-0
              [&::-webkit-slider-thumb]:transition-transform [&::-webkit-slider-thumb]:hover:scale-110
              [&::-webkit-slider-thumb]:active:scale-95"
          />
          <div className="flex justify-between text-[10px] text-text-tertiary mt-1.5">
            <span>-50%</span><span>Normal</span><span>+200%</span>
          </div>
        </div>

        {/* Impact Summary */}
        {isActive && (
          <div className="pt-3 border-t border-border space-y-2">
            <p className="text-[10px] font-semibold text-text-tertiary uppercase tracking-wider">Projected Impact</p>
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-red-500/5 rounded-lg p-2.5 text-center border border-red-500/10">
                <p className="text-lg font-bold text-red-500">{criticalCount}</p>
                <p className="text-[10px] text-text-tertiary">Critical</p>
              </div>
              <div className="bg-orange-500/5 rounded-lg p-2.5 text-center border border-orange-500/10">
                <p className="text-lg font-bold text-orange-500">{highCount}</p>
                <p className="text-[10px] text-text-tertiary">High Risk</p>
              </div>
              <div className="bg-amber-500/5 rounded-lg p-2.5 text-center border border-amber-500/10">
                <p className="text-lg font-bold text-amber-500">{alertCount}</p>
                <p className="text-[10px] text-text-tertiary">Alerts</p>
              </div>
            </div>
          </div>
        )}
      </div>
    </Card>
  );
}
