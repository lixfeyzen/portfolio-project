'use client';

import { useState, useMemo } from 'react';
import { Product, Category, SimulatorParams } from '@/lib/types';
import { calculateRiskScore } from '@/lib/risk-engine';
import { Card, CardHeader, CardTitle } from '@/components/ui/Card';
import { Badge } from '@/components/ui/Badge';
import { cn, formatCurrency, getRiskBg } from '@/lib/utils';
import { categories } from '@/data/mock-data';

interface InventoryTableProps {
  products: Product[];
  params: SimulatorParams;
}

const PAGE_SIZE = 8;
type SortKey = 'name' | 'currentStock' | 'dailyMovement' | 'riskScore' | 'unitCost';

export function InventoryTable({ products, params }: InventoryTableProps) {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<Category | 'all'>('all');
  const [riskFilter, setRiskFilter] = useState<string>('all');
  const [sortKey, setSortKey] = useState<SortKey>('riskScore');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');
  const [page, setPage] = useState(0);

  const assessed = useMemo(
    () => products.map((p) => ({ product: p, risk: calculateRiskScore(p, params) })),
    [products, params]
  );

  const filtered = useMemo(() => {
    let items = assessed;
    if (search) {
      const q = search.toLowerCase();
      items = items.filter((a) =>
        a.product.name.toLowerCase().includes(q) ||
        a.product.sku.toLowerCase().includes(q) ||
        a.product.supplier.toLowerCase().includes(q)
      );
    }
    if (categoryFilter !== 'all') items = items.filter((a) => a.product.category === categoryFilter);
    if (riskFilter !== 'all') items = items.filter((a) => a.risk.level === riskFilter);

    items.sort((a, b) => {
      let aVal: number, bVal: number;
      switch (sortKey) {
        case 'name':
          return sortDir === 'asc' ? a.product.name.localeCompare(b.product.name) : b.product.name.localeCompare(a.product.name);
        case 'currentStock': aVal = a.product.currentStock; bVal = b.product.currentStock; break;
        case 'dailyMovement': aVal = a.product.dailyMovement; bVal = b.product.dailyMovement; break;
        case 'riskScore': aVal = a.risk.score; bVal = b.risk.score; break;
        case 'unitCost': aVal = a.product.unitCost; bVal = b.product.unitCost; break;
        default: return 0;
      }
      return sortDir === 'asc' ? aVal - bVal : bVal - aVal;
    });
    return items;
  }, [assessed, search, categoryFilter, riskFilter, sortKey, sortDir]);

  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);
  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'));
    else { setSortKey(key); setSortDir('desc'); }
    setPage(0);
  };

  const SortIcon = ({ active, dir }: { active: boolean; dir: 'asc' | 'desc' }) => (
    <span className={cn('ml-1 inline-block transition-opacity', active ? 'text-accent opacity-100' : 'opacity-0 group-hover:opacity-50')}>
      {dir === 'asc' ? '↑' : '↓'}
    </span>
  );

  const getCategoryBadge = (cat: Category) => {
    const map: Record<Category, 'info' | 'success' | 'warning' | 'danger' | 'default' | 'muted'> = {
      Electronics: 'info', Apparel: 'default', 'Food & Beverage': 'success',
      Industrial: 'warning', Healthcare: 'danger', 'Office Supplies': 'muted',
    };
    return map[cat] || 'default';
  };

  const getStatusBadge = (product: any, risk: any) => {
    if (risk.isOverstocked) return <Badge variant="warning" dot>Overstock</Badge>;
    if (risk.daysUntilStockout !== null && risk.daysUntilStockout <= 5) return <Badge variant="danger" dot>{risk.daysUntilStockout}d left</Badge>;
    if (product.currentStock <= product.reorderPoint) return <Badge variant="warning" dot>Reorder</Badge>;
    return <Badge variant="success" dot>Healthy</Badge>;
  };

  return (
    <Card className="animate-fade-in">
      <CardHeader className="flex-col sm:flex-row gap-3">
        <CardTitle>Inventory Overview</CardTitle>
        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          {/* Search */}
          <div className="relative flex-1 sm:flex-initial">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"
              className="absolute left-2.5 top-1/2 -translate-y-1/2 text-text-tertiary">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
            </svg>
            <input
              type="text"
              placeholder="Search products..."
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(0); }}
              className="w-full sm:w-44 pl-8 pr-3 py-2 sm:py-1.5 text-sm sm:text-xs bg-surface-1 border border-border rounded-lg
                focus:outline-none focus:ring-2 focus:ring-accent/30 focus:border-accent/50
                text-text-primary placeholder:text-text-tertiary"
            />
          </div>

          {/* Category filter */}
          <select
            value={categoryFilter}
            onChange={(e) => { setCategoryFilter(e.target.value as any); setPage(0); }}
            className="select-styled text-sm sm:text-xs bg-surface-1 border border-border rounded-lg px-2.5 py-2 sm:py-1.5
              focus:outline-none focus:ring-2 focus:ring-accent/30 text-text-secondary appearance-none cursor-pointer"
          >
            <option value="all">All Categories</option>
            {categories.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>

          {/* Risk filter */}
          <select
            value={riskFilter}
            onChange={(e) => { setRiskFilter(e.target.value); setPage(0); }}
            className="select-styled text-sm sm:text-xs bg-surface-1 border border-border rounded-lg px-2.5 py-2 sm:py-1.5
              focus:outline-none focus:ring-2 focus:ring-accent/30 text-text-secondary appearance-none cursor-pointer"
          >
            <option value="all">All Risk</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
        </div>
      </CardHeader>

      {/* === MOBILE CARD VIEW (below md) === */}
      <div className="md:hidden space-y-2.5">
        {paginated.length === 0 && (
          <div className="text-center py-12 text-text-tertiary">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2 text-text-tertiary">
              <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
            </svg>
            <p className="text-sm">No products match your filters</p>
          </div>
        )}
        {paginated.map(({ product, risk }) => {
          const stockPct = (product.currentStock / product.maxStock) * 100;
          return (
            <div key={product.id} className="p-3 rounded-lg bg-surface-1 border border-border-subtle">
              <div className="flex items-start justify-between gap-2 mb-2">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-text-primary truncate">{product.name}</p>
                  <p className="text-[11px] text-text-tertiary">{product.sku} · {product.supplier}</p>
                </div>
                <span className={cn('flex-shrink-0 inline-flex items-center justify-center w-10 h-7 rounded-md text-xs font-bold', getRiskBg(risk.level))}>
                  {risk.score}
                </span>
              </div>
              <div className="flex items-center gap-2 mb-2">
                <Badge variant={getCategoryBadge(product.category)} className="text-[10px]">{product.category}</Badge>
                {getStatusBadge(product, risk)}
              </div>
              <div className="grid grid-cols-3 gap-3 text-center">
                <div>
                  <p className="text-[10px] text-text-tertiary">Stock</p>
                  <p className="text-xs font-semibold text-text-primary">{product.currentStock}<span className="text-text-tertiary font-normal">/{product.maxStock}</span></p>
                  <div className="w-full h-1 bg-surface-3 rounded-full mt-1">
                    <div className={cn('h-full rounded-full', stockPct > 100 ? 'bg-amber-500' : stockPct < 15 ? 'bg-red-500' : stockPct < 30 ? 'bg-orange-500' : 'bg-emerald-500')}
                      style={{ width: `${Math.min(100, stockPct)}%` }} />
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-text-tertiary">Velocity</p>
                  <p className="text-xs font-semibold text-text-primary font-mono">{product.dailyMovement}/d</p>
                </div>
                <div>
                  <p className="text-[10px] text-text-tertiary">Cost</p>
                  <p className="text-xs font-semibold text-text-primary font-mono">{formatCurrency(product.unitCost)}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* === DESKTOP TABLE VIEW (md+) === */}
      <div className="hidden md:block overflow-x-auto -mx-5">
        <table className="w-full text-xs min-w-[700px]">
          <thead>
            <tr className="border-y border-border">
              <th className="text-left font-medium text-text-tertiary px-5 py-2.5 cursor-pointer group whitespace-nowrap" onClick={() => toggleSort('name')}>
                Product<SortIcon active={sortKey === 'name'} dir={sortDir} />
              </th>
              <th className="text-left font-medium text-text-tertiary px-3 py-2.5 whitespace-nowrap">Category</th>
              <th className="text-right font-medium text-text-tertiary px-3 py-2.5 cursor-pointer group whitespace-nowrap" onClick={() => toggleSort('currentStock')}>
                Stock<SortIcon active={sortKey === 'currentStock'} dir={sortDir} />
              </th>
              <th className="text-right font-medium text-text-tertiary px-3 py-2.5 cursor-pointer group whitespace-nowrap" onClick={() => toggleSort('dailyMovement')}>
                Velocity<SortIcon active={sortKey === 'dailyMovement'} dir={sortDir} />
              </th>
              <th className="text-right font-medium text-text-tertiary px-3 py-2.5 cursor-pointer group whitespace-nowrap" onClick={() => toggleSort('unitCost')}>
                Unit Cost<SortIcon active={sortKey === 'unitCost'} dir={sortDir} />
              </th>
              <th className="text-left font-medium text-text-tertiary px-3 py-2.5 whitespace-nowrap">Status</th>
              <th className="text-center font-medium text-text-tertiary px-5 py-2.5 cursor-pointer group whitespace-nowrap" onClick={() => toggleSort('riskScore')}>
                Risk<SortIcon active={sortKey === 'riskScore'} dir={sortDir} />
              </th>
            </tr>
          </thead>
          <tbody>
            {paginated.length === 0 && (
              <tr>
                <td colSpan={7} className="text-center py-12 text-text-tertiary">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="mx-auto mb-2 text-text-tertiary">
                    <circle cx="11" cy="11" r="8" /><path d="m21 21-4.3-4.3" />
                  </svg>
                  <p>No products match your filters</p>
                </td>
              </tr>
            )}
            {paginated.map(({ product, risk }) => {
              const stockPct = (product.currentStock / product.maxStock) * 100;
              return (
                <tr key={product.id} className="border-b border-border-subtle hover:bg-surface-1 transition-colors">
                  <td className="px-5 py-3">
                    <p className="font-medium text-text-primary">{product.name}</p>
                    <p className="text-[10px] text-text-tertiary mt-0.5">{product.sku} · {product.supplier}</p>
                  </td>
                  <td className="px-3 py-3">
                    <Badge variant={getCategoryBadge(product.category)} className="text-[10px]">{product.category}</Badge>
                  </td>
                  <td className="px-3 py-3 text-right">
                    <span className="font-medium text-text-primary">{product.currentStock}</span>
                    <span className="text-text-tertiary"> / {product.maxStock}</span>
                    <div className="w-16 h-1 bg-surface-3 rounded-full mt-1 ml-auto">
                      <div className={cn('h-full rounded-full transition-all', stockPct > 100 ? 'bg-amber-500' : stockPct < 15 ? 'bg-red-500' : stockPct < 30 ? 'bg-orange-500' : 'bg-emerald-500')}
                        style={{ width: `${Math.min(100, stockPct)}%` }} />
                    </div>
                  </td>
                  <td className="px-3 py-3 text-right font-mono text-text-secondary">{product.dailyMovement}/d</td>
                  <td className="px-3 py-3 text-right font-mono text-text-secondary">{formatCurrency(product.unitCost)}</td>
                  <td className="px-3 py-3">{getStatusBadge(product, risk)}</td>
                  <td className="px-5 py-3 text-center">
                    <span className={cn('inline-flex items-center justify-center w-9 h-6 rounded-md text-[11px] font-bold', getRiskBg(risk.level))}>
                      {risk.score}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Pagination — touch-friendly */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
          <p className="text-[11px] text-text-tertiary">
            {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
          </p>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setPage((p) => Math.max(0, p - 1))}
              disabled={page === 0}
              className="h-9 px-3 text-xs rounded-lg border border-border text-text-secondary
                hover:bg-surface-2 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Prev
            </button>
            {/* Show limited pages on mobile */}
            <div className="hidden sm:flex items-center gap-1">
              {Array.from({ length: totalPages }, (_, i) => (
                <button
                  key={i}
                  onClick={() => setPage(i)}
                  className={cn('w-9 h-9 text-xs rounded-lg transition-colors', page === i ? 'bg-accent text-white font-medium' : 'text-text-secondary hover:bg-surface-2')}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <span className="sm:hidden text-xs text-text-secondary px-2">
              {page + 1}/{totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages - 1, p + 1))}
              disabled={page === totalPages - 1}
              className="h-9 px-3 text-xs rounded-lg border border-border text-text-secondary
                hover:bg-surface-2 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      )}
    </Card>
  );
}
