'use client';

import { ThemeToggle } from './ThemeToggle';
import { ViewMode, SimulatorParams } from '@/lib/types';

interface HeaderProps {
  activeView: ViewMode;
  params: SimulatorParams;
  onMenuToggle: () => void;
}

const viewLabels: Record<ViewMode, { title: string; desc: string }> = {
  dashboard: { title: 'Executive Command Center', desc: 'Real-time inventory risk overview & decision support' },
  inventory: { title: 'Inventory Management', desc: 'Complete product inventory with risk assessment' },
  analytics: { title: 'Analytics & Insights', desc: 'Stock trends, distribution, and movement velocity' },
  simulator: { title: 'Scenario Simulator', desc: 'Model demand & lead time changes to forecast risk' },
};

export function Header({ activeView, params, onMenuToggle }: HeaderProps) {
  const { title, desc } = viewLabels[activeView];
  const isSimulating = params.demandMultiplier !== 1 || params.leadTimeMultiplier !== 1;

  return (
    <header className="h-14 border-b border-border bg-surface-0/80 backdrop-blur-sm sticky top-0 z-30 flex items-center justify-between px-4 sm:px-6">
      <div className="flex items-center gap-2 sm:gap-3 min-w-0">
        {/* Hamburger — visible below lg */}
        <button
          onClick={onMenuToggle}
          className="lg:hidden w-9 h-9 flex items-center justify-center rounded-lg hover:bg-surface-2 text-text-secondary flex-shrink-0"
          aria-label="Toggle menu"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <line x1="4" y1="6" x2="20" y2="6" /><line x1="4" y1="12" x2="20" y2="12" /><line x1="4" y1="18" x2="20" y2="18" />
          </svg>
        </button>

        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-semibold text-text-primary leading-tight truncate">{title}</h1>
            {isSimulating && (
              <span className="hidden sm:inline-flex items-center gap-1 bg-amber-500/10 text-amber-600 dark:text-amber-400 text-[10px] font-semibold px-2 py-0.5 rounded-full flex-shrink-0">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse" />
                SIMULATING
              </span>
            )}
          </div>
          <p className="text-[11px] text-text-tertiary hidden sm:block">{desc}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 flex-shrink-0">
        {isSimulating && (
          <span className="sm:hidden w-2 h-2 rounded-full bg-amber-500 animate-pulse" title="Simulating" />
        )}
        <span className="text-[11px] text-text-tertiary mr-1 hidden md:block">
          {new Date().toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', year: 'numeric' })}
        </span>
        <ThemeToggle />
      </div>
    </header>
  );
}
