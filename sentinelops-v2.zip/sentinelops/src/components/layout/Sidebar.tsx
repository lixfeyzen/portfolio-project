'use client';

import { cn } from '@/lib/utils';
import { ViewMode } from '@/lib/types';
import { useEffect } from 'react';

interface SidebarProps {
  activeView: ViewMode;
  onViewChange: (view: ViewMode) => void;
  alertCount: number;
  mobileOpen: boolean;
  onMobileClose: () => void;
}

const navItems: { id: ViewMode; label: string; shortLabel: string; icon: JSX.Element }[] = [
  {
    id: 'dashboard',
    label: 'Command Center',
    shortLabel: 'Dashboard',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
        <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
      </svg>
    ),
  },
  {
    id: 'inventory',
    label: 'Inventory',
    shortLabel: 'Inventory',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z" />
        <path d="m3.3 7 8.7 5 8.7-5M12 22V12" />
      </svg>
    ),
  },
  {
    id: 'analytics',
    label: 'Analytics',
    shortLabel: 'Analytics',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M3 3v18h18" /><path d="m19 9-5 5-4-4-3 3" />
      </svg>
    ),
  },
  {
    id: 'simulator',
    label: 'Simulator',
    shortLabel: 'Simulate',
    icon: (
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
        <path d="M12 20v-6M6 20V10M18 20V4" />
      </svg>
    ),
  },
];

export function Sidebar({ activeView, onViewChange, alertCount, mobileOpen, onMobileClose }: SidebarProps) {
  // Lock body scroll when mobile sidebar open
  useEffect(() => {
    document.body.classList.toggle('menu-open', mobileOpen);
    return () => document.body.classList.remove('menu-open');
  }, [mobileOpen]);

  const handleNav = (view: ViewMode) => {
    onViewChange(view);
    onMobileClose();
  };

  return (
    <>
      {/* Desktop Sidebar (lg+) */}
      <aside className="hidden lg:flex fixed left-0 top-0 z-40 h-screen w-[220px] bg-surface-0 border-r border-border flex-col">
        <div className="h-14 px-5 flex items-center gap-2.5 border-b border-border">
          <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center flex-shrink-0">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
              <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
            </svg>
          </div>
          <div className="min-w-0">
            <span className="text-sm font-bold tracking-tight text-text-primary block">SentinelOps</span>
            <span className="block text-[10px] text-text-tertiary font-medium tracking-wide uppercase">Inventory Intel</span>
          </div>
        </div>

        <nav className="flex-1 px-3 py-4 space-y-0.5">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={cn(
                'w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all duration-150',
                activeView === item.id
                  ? 'bg-accent/10 text-accent'
                  : 'text-text-secondary hover:bg-surface-2 hover:text-text-primary'
              )}
            >
              <span className={cn(activeView === item.id ? 'text-accent' : 'text-text-tertiary')}>
                {item.icon}
              </span>
              {item.label}
              {item.id === 'dashboard' && alertCount > 0 && (
                <span className="ml-auto bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[18px] text-center">
                  {alertCount > 9 ? '9+' : alertCount}
                </span>
              )}
            </button>
          ))}
        </nav>

        <div className="px-4 py-3 border-t border-border">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-surface-2 flex items-center justify-center text-[11px] font-semibold text-text-secondary">OT</div>
            <div>
              <p className="text-xs font-medium text-text-primary">Ops Team</p>
              <p className="text-[10px] text-text-tertiary">operations@sentinel.io</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Overlay Sidebar */}
      {mobileOpen && (
        <>
          <div className="lg:hidden fixed inset-0 z-50 bg-black/40 backdrop-blur-sm" onClick={onMobileClose} />
          <aside className="lg:hidden fixed left-0 top-0 z-50 h-screen w-[260px] bg-surface-0 border-r border-border flex flex-col animate-slide-in-left">
            <div className="h-14 px-5 flex items-center justify-between border-b border-border">
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-accent flex items-center justify-center">
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10" />
                  </svg>
                </div>
                <span className="text-sm font-bold tracking-tight text-text-primary">SentinelOps</span>
              </div>
              <button onClick={onMobileClose} className="w-8 h-8 flex items-center justify-center rounded-lg hover:bg-surface-2 text-text-tertiary" aria-label="Close menu">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <path d="M18 6 6 18M6 6l12 12" />
                </svg>
              </button>
            </div>

            <nav className="flex-1 px-3 py-4 space-y-0.5">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNav(item.id)}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-3 rounded-lg text-sm font-medium transition-all',
                    activeView === item.id
                      ? 'bg-accent/10 text-accent'
                      : 'text-text-secondary hover:bg-surface-2'
                  )}
                >
                  <span className={cn(activeView === item.id ? 'text-accent' : 'text-text-tertiary')}>
                    {item.icon}
                  </span>
                  {item.label}
                  {item.id === 'dashboard' && alertCount > 0 && (
                    <span className="ml-auto bg-red-500 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full">
                      {alertCount > 9 ? '9+' : alertCount}
                    </span>
                  )}
                </button>
              ))}
            </nav>
          </aside>
        </>
      )}

      {/* Mobile Bottom Nav (sm and below) */}
      <nav className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-surface-0 border-t border-border safe-bottom">
        <div className="flex items-center justify-around px-2 py-1">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNav(item.id)}
              className={cn(
                'flex flex-col items-center gap-0.5 py-1.5 px-3 rounded-lg transition-colors min-w-[60px]',
                activeView === item.id ? 'text-accent' : 'text-text-tertiary'
              )}
            >
              <span className="relative">
                {item.icon}
                {item.id === 'dashboard' && alertCount > 0 && (
                  <span className="absolute -top-1 -right-1.5 w-2 h-2 bg-red-500 rounded-full" />
                )}
              </span>
              <span className="text-[10px] font-medium">{item.shortLabel}</span>
            </button>
          ))}
        </div>
      </nav>
    </>
  );
}
