import { cn } from '@/lib/utils';

interface SkeletonProps {
  className?: string;
}

export function Skeleton({ className }: SkeletonProps) {
  return <div className={cn('skeleton-shimmer rounded-lg', className)} />;
}

export function SkeletonCard() {
  return (
    <div className="bg-surface-0 border border-border rounded-xl p-4 sm:p-5 space-y-3">
      <Skeleton className="h-3 w-24" />
      <Skeleton className="h-8 w-32" />
      <Skeleton className="h-3 w-20" />
    </div>
  );
}

/** Matches KPICards: grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 */
export function SkeletonKPIGrid() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {[...Array(4)].map((_, i) => (
        <SkeletonCard key={i} />
      ))}
    </div>
  );
}

export function SkeletonChart() {
  return (
    <div className="bg-surface-0 border border-border rounded-xl p-4 sm:p-5 space-y-4">
      <Skeleton className="h-4 w-36" />
      <Skeleton className="h-48 sm:h-56 w-full" />
    </div>
  );
}

/** Matches dashboard 3-col: grid-cols-1 lg:grid-cols-3 */
export function SkeletonDashboardGrid() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6">
      <SkeletonChart />
      <SkeletonChart />
      <SkeletonChart />
    </div>
  );
}

export function SkeletonTable() {
  return (
    <div className="bg-surface-0 border border-border rounded-xl p-4 sm:p-5 space-y-3">
      <Skeleton className="h-4 w-48" />
      <div className="space-y-2">
        {Array.from({ length: 5 }).map((_, i) => (
          <Skeleton key={i} className="h-16 sm:h-12 w-full" />
        ))}
      </div>
    </div>
  );
}
