'use client';

import { useState, useCallback, useMemo } from 'react';
import { SimulatorParams, Product } from '@/lib/types';
import {
  calculateRiskScore,
  generateAlerts,
  calculateKPIs,
  getMovementVelocity,
  getCategoryDistribution,
} from '@/lib/risk-engine';
import { products as rawProducts } from '@/data/mock-data';

export function useSimulator() {
  const [params, setParams] = useState<SimulatorParams>({
    demandMultiplier: 1,
    leadTimeMultiplier: 1,
  });

  const products = rawProducts;

  const setDemandMultiplier = useCallback((value: number) => {
    setParams((prev) => ({ ...prev, demandMultiplier: value }));
  }, []);

  const setLeadTimeMultiplier = useCallback((value: number) => {
    setParams((prev) => ({ ...prev, leadTimeMultiplier: value }));
  }, []);

  const resetParams = useCallback(() => {
    setParams({ demandMultiplier: 1, leadTimeMultiplier: 1 });
  }, []);

  const riskAssessments = useMemo(
    () =>
      products.map((product) => ({
        product,
        risk: calculateRiskScore(product, params),
      })),
    [products, params]
  );

  const alerts = useMemo(() => generateAlerts(products, params), [products, params]);

  const kpis = useMemo(() => calculateKPIs(products, params), [products, params]);

  const movementData = useMemo(
    () => getMovementVelocity(products, params),
    [products, params]
  );

  const categoryData = useMemo(
    () => getCategoryDistribution(products),
    [products]
  );

  return {
    params,
    setDemandMultiplier,
    setLeadTimeMultiplier,
    resetParams,
    products,
    riskAssessments,
    alerts,
    kpis,
    movementData,
    categoryData,
  };
}
