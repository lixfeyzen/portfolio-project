import {
  Product,
  RiskAssessment,
  RiskFactor,
  RiskLevel,
  Alert,
  KPIData,
  SimulatorParams,
  CategoryDistItem,
  MovementData,
} from './types';

/**
 * Calculate risk score for a single product.
 * Score 0-100 where 100 = maximum risk.
 */
export function calculateRiskScore(
  product: Product,
  params: SimulatorParams = { demandMultiplier: 1, leadTimeMultiplier: 1 }
): RiskAssessment {
  const factors: RiskFactor[] = [];
  let score = 0;

  const effectiveDailyMovement = product.dailyMovement * params.demandMultiplier;
  const effectiveLeadTime = product.leadTimeDays * params.leadTimeMultiplier;

  // Factor 1: Stock Level Ratio (0-30 points)
  const stockRatio = product.currentStock / product.maxStock;
  if (stockRatio < 0.1) {
    const impact = 30;
    score += impact;
    factors.push({
      label: 'Critical Stock Level',
      impact,
      description: `Only ${Math.round(stockRatio * 100)}% of max capacity remaining`,
    });
  } else if (stockRatio < 0.25) {
    const impact = 20;
    score += impact;
    factors.push({
      label: 'Low Stock Level',
      impact,
      description: `${Math.round(stockRatio * 100)}% of max capacity remaining`,
    });
  } else if (stockRatio < 0.4) {
    const impact = 10;
    score += impact;
    factors.push({
      label: 'Moderate Stock Level',
      impact,
      description: `${Math.round(stockRatio * 100)}% of max capacity remaining`,
    });
  }

  // Factor 2: Days Until Stockout (0-30 points)
  const daysUntilStockout =
    effectiveDailyMovement > 0
      ? Math.floor(product.currentStock / effectiveDailyMovement)
      : null;

  if (daysUntilStockout !== null) {
    if (daysUntilStockout <= 3) {
      const impact = 30;
      score += impact;
      factors.push({
        label: 'Imminent Stockout',
        impact,
        description: `Only ${daysUntilStockout} days of stock remaining`,
      });
    } else if (daysUntilStockout <= 7) {
      const impact = 22;
      score += impact;
      factors.push({
        label: 'Near Stockout',
        impact,
        description: `${daysUntilStockout} days of stock remaining`,
      });
    } else if (daysUntilStockout <= 14) {
      const impact = 12;
      score += impact;
      factors.push({
        label: 'Stockout Warning',
        impact,
        description: `${daysUntilStockout} days of stock remaining`,
      });
    }
  }

  // Factor 3: Below Reorder Point (0-15 points)
  if (product.currentStock <= product.reorderPoint) {
    const severity =
      product.currentStock <= product.minStock ? 15 : 10;
    score += severity;
    factors.push({
      label: 'Below Reorder Point',
      impact: severity,
      description: `Current: ${product.currentStock}, Reorder at: ${product.reorderPoint}`,
    });
  }

  // Factor 4: Lead Time Risk (0-15 points)
  if (effectiveLeadTime > 14) {
    const impact = 15;
    score += impact;
    factors.push({
      label: 'Long Lead Time',
      impact,
      description: `${Math.round(effectiveLeadTime)} days to restock`,
    });
  } else if (effectiveLeadTime > 7) {
    const impact = 8;
    score += impact;
    factors.push({
      label: 'Moderate Lead Time',
      impact,
      description: `${Math.round(effectiveLeadTime)} days to restock`,
    });
  }

  // Factor 5: High Movement + Low Stock combo (0-10 points)
  if (effectiveDailyMovement > 10 && stockRatio < 0.3) {
    const impact = 10;
    score += impact;
    factors.push({
      label: 'High Velocity Risk',
      impact,
      description: `${effectiveDailyMovement.toFixed(0)} units/day with ${Math.round(stockRatio * 100)}% stock`,
    });
  }

  // Cap at 100
  score = Math.min(100, score);

  // Determine level
  let level: RiskLevel;
  if (score >= 70) level = 'critical';
  else if (score >= 45) level = 'high';
  else if (score >= 20) level = 'medium';
  else level = 'low';

  // Check overstock
  const isOverstocked = product.currentStock > product.maxStock;

  // Calculate suggested reorder
  const safetyStock = Math.ceil(effectiveDailyMovement * effectiveLeadTime * 0.5);
  const suggestedReorder = Math.max(
    0,
    Math.ceil(
      product.maxStock * 0.7 - product.currentStock + safetyStock
    )
  );

  return {
    score,
    level,
    factors,
    daysUntilStockout,
    suggestedReorder: isOverstocked ? 0 : suggestedReorder,
    isOverstocked,
  };
}

/**
 * Generate alerts for all products
 */
export function generateAlerts(
  products: Product[],
  params: SimulatorParams = { demandMultiplier: 1, leadTimeMultiplier: 1 }
): Alert[] {
  const alerts: Alert[] = [];

  products.forEach((product) => {
    const risk = calculateRiskScore(product, params);
    const now = new Date().toISOString();

    if (risk.daysUntilStockout !== null && risk.daysUntilStockout <= 5) {
      alerts.push({
        id: `alert-stockout-${product.id}`,
        productId: product.id,
        productName: product.name,
        type: 'stockout',
        severity: risk.daysUntilStockout <= 2 ? 'critical' : 'warning',
        message: `Will run out in ${risk.daysUntilStockout} day${risk.daysUntilStockout !== 1 ? 's' : ''} at current demand rate`,
        timestamp: now,
      });
    }

    if (risk.isOverstocked) {
      const excess = product.currentStock - product.maxStock;
      alerts.push({
        id: `alert-overstock-${product.id}`,
        productId: product.id,
        productName: product.name,
        type: 'overstock',
        severity: 'warning',
        message: `Overstocked by ${excess} units (${Math.round((excess / product.maxStock) * 100)}% over capacity)`,
        timestamp: now,
      });
    }

    if (risk.level === 'critical') {
      alerts.push({
        id: `alert-risk-${product.id}`,
        productId: product.id,
        productName: product.name,
        type: 'high-risk',
        severity: 'critical',
        message: `Risk score ${risk.score}/100 — Immediate attention required`,
        timestamp: now,
      });
    }

    if (
      product.currentStock <= product.reorderPoint &&
      !risk.isOverstocked &&
      risk.suggestedReorder > 0
    ) {
      alerts.push({
        id: `alert-reorder-${product.id}`,
        productId: product.id,
        productName: product.name,
        type: 'reorder',
        severity: 'info',
        message: `Recommend reorder of ${risk.suggestedReorder} units from ${product.supplier}`,
        timestamp: now,
      });
    }
  });

  // Sort by severity
  const severityOrder = { critical: 0, warning: 1, info: 2 };
  return alerts.sort(
    (a, b) => severityOrder[a.severity] - severityOrder[b.severity]
  );
}

/**
 * Calculate KPI metrics
 */
export function calculateKPIs(
  products: Product[],
  params: SimulatorParams = { demandMultiplier: 1, leadTimeMultiplier: 1 }
): KPIData {
  let totalValue = 0;
  let criticalCount = 0;
  let overstockCount = 0;
  let fastMovingCount = 0;
  let totalRisk = 0;

  products.forEach((product) => {
    totalValue += product.currentStock * product.unitCost;
    const risk = calculateRiskScore(product, params);
    totalRisk += risk.score;

    if (risk.level === 'critical' || risk.level === 'high') criticalCount++;
    if (risk.isOverstocked) overstockCount++;
    if (product.dailyMovement * params.demandMultiplier >= 8) fastMovingCount++;
  });

  return {
    totalInventoryValue: totalValue,
    criticalRiskItems: criticalCount,
    overstockItems: overstockCount,
    fastMovingProducts: fastMovingCount,
    totalProducts: products.length,
    avgRiskScore: Math.round(totalRisk / products.length),
  };
}

/**
 * Get category distribution data
 */
export function getCategoryDistribution(products: Product[]): CategoryDistItem[] {
  const map = new Map<string, { count: number; value: number }>();
  products.forEach((p) => {
    const existing = map.get(p.category) || { count: 0, value: 0 };
    existing.count++;
    existing.value += p.currentStock * p.unitCost;
    map.set(p.category, existing);
  });

  return Array.from(map.entries()).map(([category, data]) => ({
    category: category as any,
    count: data.count,
    value: Math.round(data.value),
  }));
}

/**
 * Get movement velocity data
 */
export function getMovementVelocity(
  products: Product[],
  params: SimulatorParams = { demandMultiplier: 1, leadTimeMultiplier: 1 }
): MovementData[] {
  return products
    .map((p) => ({
      name: p.name.length > 20 ? p.name.slice(0, 18) + '…' : p.name,
      velocity: Math.round(p.dailyMovement * params.demandMultiplier * 10) / 10,
      stock: p.currentStock,
    }))
    .sort((a, b) => b.velocity - a.velocity)
    .slice(0, 10);
}
