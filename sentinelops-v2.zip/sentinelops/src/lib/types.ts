export interface Product {
  id: string;
  name: string;
  sku: string;
  category: Category;
  currentStock: number;
  maxStock: number;
  minStock: number;
  reorderPoint: number;
  unitCost: number;
  dailyMovement: number;
  leadTimeDays: number;
  supplier: string;
  lastRestocked: string;
  trend: 'up' | 'down' | 'stable';
}

export type Category =
  | 'Electronics'
  | 'Apparel'
  | 'Food & Beverage'
  | 'Industrial'
  | 'Healthcare'
  | 'Office Supplies';

export type RiskLevel = 'critical' | 'high' | 'medium' | 'low';

export interface RiskAssessment {
  score: number;
  level: RiskLevel;
  factors: RiskFactor[];
  daysUntilStockout: number | null;
  suggestedReorder: number;
  isOverstocked: boolean;
}

export interface RiskFactor {
  label: string;
  impact: number;
  description: string;
}

export interface Alert {
  id: string;
  productId: string;
  productName: string;
  type: 'stockout' | 'overstock' | 'high-risk' | 'reorder';
  severity: 'critical' | 'warning' | 'info';
  message: string;
  timestamp: string;
}

export interface SimulatorParams {
  demandMultiplier: number;
  leadTimeMultiplier: number;
}

export interface KPIData {
  totalInventoryValue: number;
  criticalRiskItems: number;
  overstockItems: number;
  fastMovingProducts: number;
  totalProducts: number;
  avgRiskScore: number;
}

export interface StockTrendPoint {
  date: string;
  stock: number;
  projected: number;
}

export interface CategoryDistItem {
  category: Category;
  count: number;
  value: number;
}

export interface MovementData {
  name: string;
  velocity: number;
  stock: number;
}

export type SortDirection = 'asc' | 'desc';

export interface TableSort {
  key: string;
  direction: SortDirection;
}

export type ViewMode = 'dashboard' | 'inventory' | 'analytics' | 'simulator';
